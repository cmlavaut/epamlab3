#!/bin/bash
npm install